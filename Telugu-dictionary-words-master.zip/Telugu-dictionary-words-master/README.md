# Telugu-dictionary-words

The file `sortdict.txt` contains ```54,197``` telugu words, compiled by merging all words from various Telugu dictionaries. They are articulated in alphabetical order.
